import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.*;

import static io.restassured.RestAssured.given;


public class MyStepdefs {

    int result = 0;
    String response;

    @Given("I add {int} + {int}")
    public void iAdd(int arg0, int arg1) {
        result = arg0 + arg1;
    }

    @Then("a {int} should be returned")
    public void aShouldBeReturned(int arg0) {
        System.out.println(result);
    }

    @Given("I send a GET request")
    public void iSendAGETRequest() {
        response = given().when().get("http://dummy.restapiexample.com/api/v1/employees").then().extract().asString();
    }

    @Then("I should get a response")
    public void iShouldGetAResponse() {
        System.out.println(response);
    }
}
